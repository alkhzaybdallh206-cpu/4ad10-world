/* ============================================================
   4_AD10 — محتوى الموقع (عدّل هنا فقط، بدون لمس باقي الملفات)
   ============================================================ */
window.SITE = {
  /* ---- الحسابات الرسمية ---- */
  socials: [
    { id: 'tiktok',    name: 'TikTok',    handle: '@4_ad10', url: 'https://www.tiktok.com/@4_ad10',   tag: 'WATCH',   blurb: 'مقاطع قصيرة ومونتاج أنمي بإيقاع سريع.' },
    { id: 'instagram', name: 'Instagram', handle: '@4_ad10', url: 'https://www.instagram.com/4_ad10', tag: 'CONTACT', blurb: 'للتواصل المباشر والتعاون.' },
    { id: 'youtube',   name: 'YouTube',   handle: '@4_ad10', url: 'https://youtube.com/@4_ad10',      tag: 'WATCH',   blurb: 'الأعمال الكاملة بجودة عالية.' }
  ],

  /* ---- أعمال المونتاج ----
     yt    : معرّف فيديو يوتيوب (الجزء بعد v=) — يظهر الغلاف والتشغيل داخل الموقع تلقائياً
     url   : الرابط الأصلي للعمل (يوتيوب / تيك توك / انستغرام)
     thumb : (اختياري) صورة غلاف خاصة، مثل assets/works/01.jpg
     استبدل العناصر التجريبية بأعمالك الحقيقية.                           */
  works: [
    { title: 'عمل 01', tag: 'AMV',        yt: '', url: 'https://youtube.com/@4_ad10', thumb: '' },
    { title: 'عمل 02', tag: 'ANIME EDIT', yt: '', url: 'https://youtube.com/@4_ad10', thumb: '' },
    { title: 'عمل 03', tag: 'AMV',        yt: '', url: 'https://youtube.com/@4_ad10', thumb: '' },
    { title: 'عمل 04', tag: 'SHORT',      yt: '', url: 'https://www.tiktok.com/@4_ad10', thumb: '' },
    { title: 'عمل 05', tag: 'ANIME EDIT', yt: '', url: 'https://youtube.com/@4_ad10', thumb: '' },
    { title: 'عمل 06', tag: 'AMV',        yt: '', url: 'https://youtube.com/@4_ad10', thumb: '' }
  ],

  /* ---- معرض الصور (ضع الصور في assets/gallery/) ---- */
  gallery: [
    { src: 'assets/gallery/01.jpg', alt: 'صورة 01' },
    { src: 'assets/gallery/02.jpg', alt: 'صورة 02' },
    { src: 'assets/gallery/03.jpg', alt: 'صورة 03' },
    { src: 'assets/gallery/04.jpg', alt: 'صورة 04' },
    { src: 'assets/gallery/05.jpg', alt: 'صورة 05' },
    { src: 'assets/gallery/06.jpg', alt: 'صورة 06' },
    { src: 'assets/gallery/07.jpg', alt: 'صورة 07' },
    { src: 'assets/gallery/08.jpg', alt: 'صورة 08' },
    { src: 'assets/gallery/09.jpg', alt: 'صورة 09' }
  ],

  /* ---- التصويتات ---- */
  polls: [
    { id: 'p1', q: 'أي نوع مونتاج تريد في الفيديو القادم؟', options: ['AMV درامي', 'إيقاع سريع / Phonk', 'مشاهد قتال', 'مشاهد حزينة'] },
    { id: 'p2', q: 'أي طابع بصري تفضّله؟', options: ['أسود وأحمر', 'أبيض وأسود', 'ألوان باردة'] }
  ]
};
