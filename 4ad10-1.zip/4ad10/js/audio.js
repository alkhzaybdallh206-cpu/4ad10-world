/* 4_AD10 — محرك الصوت (مُولَّد بالكامل بـ Web Audio، بدون ملفات خارجية)
   لا يعمل أي صوت قبل تفاعل المستخدم، ويحترم حالة الكتم المحفوظة. */
(function () {
  const KEY = 'ad10_sound';
  let ctx = null, master = null, droneNodes = null;
  let enabled = false, vol = 0.6;

  try {
    const s = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (s) { vol = typeof s.vol === 'number' ? s.vol : vol; }
  } catch (e) {}

  function save() { try { localStorage.setItem(KEY, JSON.stringify({ on: enabled, vol })); } catch (e) {} }

  function ensure() {
    if (ctx) return true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = enabled ? vol : 0;
    const comp = ctx.createDynamicsCompressor();
    master.connect(comp); comp.connect(ctx.destination);
    return true;
  }
  const live = () => enabled && ctx && ctx.state !== 'closed';

  function noiseBuf(sec) {
    const n = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }
  function tone(f0, f1, dur, type, g, delay) {
    const t = ctx.currentTime + (delay || 0), o = ctx.createOscillator(), a = ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(f0, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    a.gain.setValueAtTime(0.0001, t);
    a.gain.exponentialRampToValueAtTime(g, t + Math.min(0.02, dur / 3));
    a.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(a); a.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(dur, g, f0, f1, q, type, delay) {
    const t = ctx.currentTime + (delay || 0), s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), a = ctx.createGain();
    s.buffer = noiseBuf(dur + 0.1);
    f.type = type || 'bandpass'; f.Q.value = q || 1;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    a.gain.setValueAtTime(0.0001, t);
    a.gain.exponentialRampToValueAtTime(g, t + dur * 0.35);
    a.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(a); a.connect(master); s.start(t); s.stop(t + dur + 0.1);
  }

  const fx = {
    boom() {          // دخول سينمائي: نبضة عميقة + صعود غامض
      tone(70, 28, 2.4, 'sine', 0.9);
      tone(140, 40, 1.4, 'triangle', 0.25);
      noise(2.2, 0.35, 120, 2400, 0.8, 'lowpass');
      tone(110, 220, 1.8, 'sawtooth', 0.05, 0.1);
      tone(1760, 880, 1.2, 'sine', 0.04, 0.5);
    },
    whoosh() { noise(0.7, 0.28, 220, 2600, 1.2, 'bandpass'); noise(0.5, 0.2, 2600, 260, 1.2, 'bandpass', 0.3); tone(90, 45, 0.5, 'sine', 0.3); },
    click()  { tone(920, 380, 0.07, 'square', 0.07); noise(0.04, 0.12, 3000, 1500, 1, 'highpass'); },
    hover()  { tone(1500, 1700, 0.05, 'triangle', 0.02); },
    reveal() { tone(520, 780, 0.22, 'sine', 0.03); },
    glitch() {
      for (let i = 0; i < 6; i++) tone(120 + Math.random() * 1300, 0, 0.045, 'square', 0.05, i * 0.045);
      noise(0.3, 0.15, 6000, 800, 2, 'bandpass');
    },
    open()   { tone(300, 900, 0.3, 'sine', 0.08); noise(0.3, 0.1, 400, 3000, 1, 'bandpass'); },
    vote()   { tone(660, 990, 0.14, 'sine', 0.07); tone(990, 1320, 0.18, 'sine', 0.05, 0.1); }
  };

  function startDrone() {
    if (!ctx || droneNodes) return;
    const g = ctx.createGain(); g.gain.value = 0.0001;
    g.gain.exponentialRampToValueAtTime(0.05, ctx.currentTime + 4);
    const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 260;
    const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 0.07; lg.gain.value = 90;
    lfo.connect(lg); lg.connect(f.frequency);
    const a = ctx.createOscillator(), b = ctx.createOscillator();
    a.type = 'sawtooth'; b.type = 'sawtooth'; a.frequency.value = 55; b.frequency.value = 55.6;
    a.connect(f); b.connect(f); f.connect(g); g.connect(master);
    a.start(); b.start(); lfo.start();
    droneNodes = { g, stop() { try { a.stop(); b.stop(); lfo.stop(); } catch (e) {} } };
  }
  function stopDrone() {
    if (!droneNodes) return;
    try { droneNodes.g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.6); } catch (e) {}
    const d = droneNodes; droneNodes = null; setTimeout(() => d.stop(), 700);
  }

  const Sound = {
    get on() { return enabled; },
    get vol() { return vol; },
    /* يُستدعى من تفاعل مباشر للمستخدم فقط */
    enable() {
      if (!ensure()) return false;
      enabled = true;
      if (ctx.state === 'suspended') ctx.resume();
      master.gain.cancelScheduledValues(ctx.currentTime);
      master.gain.setTargetAtTime(vol, ctx.currentTime, 0.05);
      startDrone(); save(); this.onchange && this.onchange(); return true;
    },
    disable() {
      enabled = false;
      if (ctx && master) { master.gain.setTargetAtTime(0, ctx.currentTime, 0.05); stopDrone(); }
      save(); this.onchange && this.onchange();
    },
    toggle() { enabled ? this.disable() : this.enable(); },
    setVolume(v) {
      vol = Math.max(0, Math.min(1, v));
      if (ctx && master && enabled) master.gain.setTargetAtTime(vol, ctx.currentTime, 0.03);
      save();
    },
    play(name) { if (live() && fx[name]) { try { if (ctx.state === 'suspended') ctx.resume(); fx[name](); } catch (e) {} } },
    onchange: null
  };

  document.addEventListener('visibilitychange', () => {
    if (!ctx) return;
    if (document.hidden) ctx.suspend(); else if (enabled) ctx.resume();
  });

  window.Sound = Sound;
})();
