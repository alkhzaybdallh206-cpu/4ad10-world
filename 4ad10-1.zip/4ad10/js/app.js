/* 4_AD10 — المنطق الرئيسي: التحميل، التنقل والانتقالات، الظهور التدريجي، المحتوى */
(() => {
  'use strict';
  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const wait = ms => new Promise(r => setTimeout(r, ms));
  const mqReduce = matchMedia('(prefers-reduced-motion: reduce)');
  const reduced = () => mqReduce.matches;
  const canHover = matchMedia('(hover:hover) and (pointer:fine)').matches;
  const DATA = window.SITE, Sound = window.Sound;
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  const pad = n => String(n).padStart(2, '0');

  /* ---------- الصفحات وأنماط الانتقال ---------- */
  const ORDER = ['home', 'about', 'works', 'gallery', 'community', 'socials'];
  const TYPE  = { home: 'fade', about: 'line', works: 'glitch', gallery: '3d', community: 'zoom', socials: 'black' };
  const DUR   = { fade: 450, line: 750, glitch: 560, black: 700 };
  let current = ORDER.includes(location.hash.slice(1)) ? location.hash.slice(1) : 'home';
  let busy = false, ready = false;

  /* ---------- الصور الاحتياطية للشخصية ---------- */
  function charFallbacks() {
    $$('img[data-char]').forEach(img => {
      const bad = () => { img.style.display = 'none'; const ph = img.parentElement.querySelector('.char-ph'); if (ph) ph.hidden = false; };
      img.addEventListener('error', bad);
      if (img.complete && !img.naturalWidth) bad();
    });
  }

  /* ---------- تقسيم النصوص للظهور ---------- */
  function splitHeadings() {
    $$('[data-reveal="text"]').forEach(el => {
      const txt = el.textContent.trim();
      el.setAttribute('aria-label', txt);
      el.innerHTML = txt.split(/\s+/).map((w, i) => `<span class="mask" aria-hidden="true"><span style="--i:${i}">${w}</span></span>`).join(' ');
    });
  }

  /* ---------- مراقب الظهور ---------- */
  const io = 'IntersectionObserver' in window ? new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      e.target.classList.add('in'); io.unobserve(e.target);
      if (e.target.dataset.reveal === 'text') Sound.play('reveal');
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' }) : null;

  function armReveals(page) {
    $$('[data-reveal]', page).forEach(el => { el.classList.remove('in'); io ? io.observe(el) : el.classList.add('in'); });
  }

  /* ---------- تحميل البيانات إلى الصفحات ---------- */
  function gradientFor(i) { return `linear-gradient(${135 + i * 17}deg,#0b0b0d 0%,#1a0608 ${40 + (i % 3) * 10}%,#050505 100%)`; }
  function thumbOf(w, i) {
    if (w.thumb) return `url("${w.thumb}")`;
    if (w.yt) return `url("https://i.ytimg.com/vi/${w.yt}/hqdefault.jpg")`;
    return gradientFor(i);
  }

  function renderWorks() {
    const grid = $('#works-grid');
    DATA.works.forEach((w, i) => {
      const el = document.createElement('article');
      el.className = 'work'; el.tabIndex = 0; el.setAttribute('role', 'button');
      el.setAttribute('aria-label', 'فتح ' + w.title);
      el.dataset.reveal = 'up'; el.style.setProperty('--d', (i % 3) * 0.1 + 's');
      el.innerHTML =
        `<div class="work-thumb" style="background-image:${thumbOf(w, i)}"><span class="work-no">${pad(i + 1)}</span>` +
        `<span class="play"><svg viewBox="0 0 24 24" width="22" height="22"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg></span><i class="scan"></i></div>` +
        `<div class="work-info"><small></small><h3></h3></div><span class="work-line"></span>`;
      $('small', el).textContent = w.tag; $('h3', el).textContent = w.title;
      const open = () => openWork(w, i, el);
      el.addEventListener('click', open);
      el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
      grid.appendChild(el);
    });
  }

  function renderGallery() {
    const grid = $('#gal-grid');
    DATA.gallery.forEach((g, i) => {
      const b = document.createElement('button');
      b.className = 'tile t' + (i % 9); b.type = 'button'; b.dataset.reveal = 'up';
      b.style.setProperty('--d', (i % 4) * 0.08 + 's'); b.style.setProperty('--g', gradientFor(i));
      b.setAttribute('aria-label', 'تكبير ' + g.alt);
      const img = new Image(); img.loading = 'lazy'; img.decoding = 'async'; img.alt = g.alt; img.src = g.src;
      img.addEventListener('error', () => { b.classList.add('empty'); img.remove(); });
      b.appendChild(img);
      b.insertAdjacentHTML('beforeend', `<span class="tile-no">${pad(i + 1)}</span><span class="tile-ghost">♚</span>`);
      b.addEventListener('click', () => openLightbox(i));
      grid.appendChild(b);
    });
  }

  const LOGOS = {
    tiktok: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.6 3c.3 2.5 1.8 4.2 4.4 4.5v3.3c-1.6 0-3-.5-4.4-1.4v6.2a6.1 6.1 0 1 1-6.1-6.1c.3 0 .7 0 1 .1v3.4a2.8 2.8 0 1 0 1.8 2.6V3h3.3z"/></svg>',
    instagram: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1" fill="currentColor" stroke="none"/></svg>',
    youtube: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2C2 8.8 2 12 2 12s0 3.2.4 4.8a2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8c.4-1.6.4-4.8.4-4.8s0-3.2-.4-4.8zM10 15V9l5.2 3z"/></svg>'
  };
  function renderSocials() {
    const grid = $('#soc-grid');
    DATA.socials.forEach((s, i) => {
      const a = document.createElement('a');
      a.className = 'soc-card'; a.href = s.url; a.target = '_blank'; a.rel = 'noopener noreferrer';
      a.dataset.reveal = 'up'; a.style.setProperty('--d', i * 0.12 + 's'); a.setAttribute('aria-label', s.name + ' ' + s.handle);
      a.innerHTML =
        `<span class="soc-tag">${s.tag}</span><span class="soc-logo">${LOGOS[s.id] || ''}</span>` +
        `<h3>${s.name}</h3><p class="soc-handle" dir="ltr">${s.handle}</p><p class="soc-blurb">${s.blurb}</p>` +
        `<span class="soc-go"><span>OPEN</span><i>↗</i></span><i class="soc-bar"></i>`;
      grid.appendChild(a);
    });
    $('#yr').textContent = new Date().getFullYear();
  }

  /* ---------- المجتمع: اقتراحات + تصويتات (تُحفظ على الجهاز) ---------- */
  function renderCommunity() {
    const list = $('#sug-list'), countEl = $('#sug-count');
    let sugs = store.get('ad10_sug', []), liked = store.get('ad10_liked', {});
    const draw = () => {
      list.textContent = ''; countEl.textContent = sugs.length;
      if (!sugs.length) { const li = document.createElement('li'); li.className = 'empty'; li.textContent = 'لا توجد اقتراحات بعد — كن أول من يقترح.'; list.appendChild(li); return; }
      [...sugs].sort((a, b) => b.likes - a.likes || b.t - a.t).forEach(s => {
        const li = document.createElement('li');
        const info = document.createElement('div'); info.className = 'sug-info';
        const h = document.createElement('b'); h.textContent = s.char;
        const sm = document.createElement('small'); sm.textContent = s.anime; sm.dir = 'auto';
        info.append(h, sm);
        if (s.why) { const p = document.createElement('p'); p.textContent = s.why; info.appendChild(p); }
        const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'like' + (liked[s.id] ? ' on' : '');
        btn.setAttribute('aria-label', 'إعجاب'); btn.innerHTML = '<i>♚</i><span></span>'; $('span', btn).textContent = s.likes;
        btn.addEventListener('click', () => {
          if (liked[s.id]) { liked[s.id] = false; s.likes = Math.max(0, s.likes - 1); } else { liked[s.id] = true; s.likes++; Sound.play('vote'); }
          store.set('ad10_sug', sugs); store.set('ad10_liked', liked); draw();
        });
        li.append(info, btn); list.appendChild(li);
      });
    };
    $('#sug-form').addEventListener('submit', e => {
      e.preventDefault();
      const f = e.target, char = f.char.value.trim(), anime = f.anime.value.trim(), why = f.why.value.trim();
      if (!char || !anime) return;
      sugs.unshift({ id: Date.now().toString(36), char, anime, why, likes: 0, t: Date.now() });
      sugs = sugs.slice(0, 50); store.set('ad10_sug', sugs); f.reset(); Sound.play('vote'); draw();
    });
    draw();

    /* التصويتات */
    const box = $('#polls'); let votes = store.get('ad10_votes', {}), mine = store.get('ad10_mine', {});
    DATA.polls.forEach((p, pi) => {
      const art = document.createElement('article'); art.className = 'card poll'; art.dataset.reveal = 'up'; art.style.setProperty('--d', (0.1 * pi) + 's');
      const top = document.createElement('div'); top.className = 'card-top';
      top.innerHTML = `<b>${pad(pi + 3)}</b><h3></h3>`; $('h3', top).textContent = p.q;
      const ul = document.createElement('ul'); ul.className = 'opts';
      art.append(top, ul);
      const draw2 = () => {
        const v = votes[p.id] || p.options.map(() => 0), total = v.reduce((a, b) => a + b, 0), voted = mine[p.id] !== undefined;
        ul.textContent = '';
        p.options.forEach((o, i) => {
          const li = document.createElement('li'), b = document.createElement('button');
          b.type = 'button'; b.className = 'opt' + (mine[p.id] === i ? ' mine' : ''); b.disabled = voted;
          const pct = total ? Math.round(v[i] / total * 100) : 0;
          b.innerHTML = `<i class="bar" style="width:${voted ? pct : 0}%"></i><span class="lbl"></span><span class="pct">${voted ? pct + '%' : ''}</span>`;
          $('.lbl', b).textContent = o;
          b.addEventListener('click', () => {
            if (mine[p.id] !== undefined) return;
            const nv = votes[p.id] || p.options.map(() => 0); nv[i]++; votes[p.id] = nv; mine[p.id] = i;
            store.set('ad10_votes', votes); store.set('ad10_mine', mine); Sound.play('vote'); draw2();
          });
          li.appendChild(b); ul.appendChild(li);
        });
      };
      draw2(); box.appendChild(art);
    });
  }

  /* ---------- نافذة العمل ---------- */
  let lastFocus = null;
  function lock(on) { document.documentElement.classList.toggle('no-scroll', on); }
  function openWork(w, i, from) {
    lastFocus = from || document.activeElement;
    const m = $('#modal'), media = $('#modal-media');
    media.textContent = '';
    if (w.yt) {
      const f = document.createElement('iframe');
      f.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(w.yt)}?autoplay=1&rel=0`;
      f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.allowFullscreen = true; f.title = w.title;
      media.appendChild(f);
    } else {
      const d = document.createElement('div'); d.className = 'poster'; d.style.backgroundImage = thumbOf(w, i);
      d.innerHTML = '<div><span>♚</span><p>هذا العمل يُشاهَد من الرابط الأصلي</p></div>';
      media.appendChild(d);
    }
    $('#modal-title').textContent = w.title; $('#modal-tag').textContent = w.tag; $('#modal-link').href = w.url;
    m.hidden = false; requestAnimationFrame(() => m.classList.add('open')); lock(true); Sound.play('open');
    $('.x', m).focus();
  }
  function closeModal() {
    const m = $('#modal'); if (m.hidden) return;
    m.classList.remove('open'); lock(false);
    setTimeout(() => { m.hidden = true; $('#modal-media').textContent = ''; }, 350);
    lastFocus && lastFocus.focus && lastFocus.focus({ preventScroll: true });
  }

  /* ---------- معرض الصور (Lightbox) ---------- */
  const lb = $('#lightbox'); lb.dir = 'ltr';
  let lbi = 0, lbBusy = false;
  function lbRender(i) {
    const g = DATA.gallery[i], fig = $('#lb-fig'); fig.textContent = '';
    const img = new Image(); img.alt = g.alt; img.decoding = 'async'; img.src = g.src;
    img.addEventListener('error', () => {
      const d = document.createElement('div'); d.className = 'lb-empty'; d.style.background = gradientFor(i); d.innerHTML = '<span>♚</span>';
      img.replaceWith(d);
    });
    fig.appendChild(img);
    $('#lb-count').textContent = pad(i + 1) + ' / ' + pad(DATA.gallery.length);
  }
  function openLightbox(i) {
    lastFocus = document.activeElement; lbi = i; lbRender(i);
    lb.hidden = false; requestAnimationFrame(() => lb.classList.add('open')); lock(true); Sound.play('open'); $('.x', lb).focus();
  }
  function closeLightbox() {
    if (lb.hidden) return; lb.classList.remove('open'); lock(false);
    setTimeout(() => { lb.hidden = true; $('#lb-fig').textContent = ''; }, 350);
    lastFocus && lastFocus.focus && lastFocus.focus({ preventScroll: true });
  }
  async function lbStep(d) {
    if (lbBusy || lb.hidden) return; lbBusy = true;
    const fig = $('#lb-fig'), n = DATA.gallery.length;
    fig.style.setProperty('--dir', d);
    fig.classList.add('out'); Sound.play('click');
    await wait(reduced() ? 10 : 220);
    lbi = (lbi + d + n) % n; lbRender(lbi);
    fig.classList.remove('out'); fig.classList.add('pre'); void fig.offsetWidth; fig.classList.remove('pre');
    await wait(reduced() ? 10 : 260); lbBusy = false;
  }
  $('#lb-prev').addEventListener('click', () => lbStep(-1));
  $('#lb-next').addEventListener('click', () => lbStep(1));
  let tsx = null;
  lb.addEventListener('touchstart', e => { tsx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', e => { if (tsx === null) return; const dx = e.changedTouches[0].clientX - tsx; tsx = null; if (Math.abs(dx) > 50) lbStep(dx < 0 ? 1 : -1); }, { passive: true });

  document.addEventListener('click', e => { if (e.target.closest('[data-close]')) { closeModal(); closeLightbox(); } });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeModal(); closeLightbox(); }
    if (!lb.hidden) { if (e.key === 'ArrowLeft') lbStep(-1); if (e.key === 'ArrowRight') lbStep(1); }
    if (e.key === 'Tab') { const box = !$('#modal').hidden ? $('#modal') : !lb.hidden ? lb : null; if (box) { const f = $$('button,a[href],iframe', box).filter(x => !x.disabled && x.offsetParent !== null); if (f.length) { const first = f[0], last = f[f.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); } } } }
  });

  /* ---------- شريط التنقل ---------- */
  function updateNav() {
    $$('[data-go]').forEach(a => { if (a.tagName === 'A' && (a.closest('.nav-links') || a.closest('.tabbar'))) a.classList.toggle('active', a.dataset.go === current); });
    const idx = ORDER.indexOf(current), link = $(`.nav-links a[data-go="${current}"]`), line = $('#nav-line');
    if (link && line && link.offsetWidth) { line.style.width = link.offsetWidth + 'px'; line.style.transform = `translateX(${link.offsetLeft}px)`; }
    const tl = $('#tab-line'); if (tl) tl.style.transform = `translateX(${idx * 100}%)`;
  }
  addEventListener('resize', updateNav);

  /* ---------- الانتقالات ---------- */
  async function overlay(type, swap) {
    const fx = $('#fx'); fx.dataset.type = type; fx.classList.add('on');
    void fx.offsetWidth; fx.classList.add('in');
    await wait(reduced() ? 240 : DUR[type] + 40);
    if (type === 'black') await wait(reduced() ? 0 : 420);
    swap();
    await wait(60);
    fx.classList.remove('in');
    await wait(reduced() ? 260 : DUR[type] + 80);
    fx.classList.remove('on');
  }
  async function pageAnim(type, swap) {
    const old = $('#' + current), pre = $('#fx'); pre.dataset.type = 'dim'; pre.classList.add('on'); void pre.offsetWidth; pre.classList.add('in');
    const out = type === '3d'
      ? [{ transform: 'perspective(1400px) rotateY(0) scale(1)', opacity: 1 }, { transform: 'perspective(1400px) rotateY(-24deg) translateX(-8%) scale(.86)', opacity: 0 }]
      : [{ transform: 'scale(1)', opacity: 1, filter: 'blur(0)' }, { transform: 'scale(1.35)', opacity: 0, filter: 'blur(8px)' }];
    const inn = type === '3d'
      ? [{ transform: 'perspective(1400px) rotateY(24deg) translateX(8%) scale(.86)', opacity: 0 }, { transform: 'perspective(1400px) rotateY(0) scale(1)', opacity: 1 }]
      : [{ transform: 'scale(.78)', opacity: 0, filter: 'blur(8px)' }, { transform: 'scale(1)', opacity: 1, filter: 'blur(0)' }];
    await old.animate(out, { duration: 520, easing: 'cubic-bezier(.5,0,.75,0)', fill: 'forwards' }).finished.catch(() => {});
    swap();
    const nw = $('#' + ORDER_TARGET);
    const a = nw.animate(inn, { duration: 780, easing: 'cubic-bezier(.22,.8,.2,1)' });
    pre.classList.remove('in'); await a.finished.catch(() => {});
    pre.classList.remove('on'); old.getAnimations().forEach(x => x.cancel());
  }
  let ORDER_TARGET = 'home';

  async function go(id, push = true) {
    if (!ORDER.includes(id) || id === current) return;
    if (busy) return;
    busy = true; ORDER_TARGET = id;
    const type = reduced() ? 'fade' : TYPE[id];
    Sound.play(type === 'glitch' ? 'glitch' : 'whoosh');
    const swap = () => {
      $('#' + current).classList.remove('active');
      const pg = $('#' + id); $$('[data-reveal].in', pg).forEach(e => e.classList.remove('in'));
      pg.classList.add('active'); current = id; scrollTo(0, 0);
      document.title = '4_AD10 — ' + pg.dataset.title;
      pg.setAttribute('tabindex', '-1'); pg.focus({ preventScroll: true });
      updateNav();
    };
    if (push) history.pushState({ id }, '', '#' + id);
    updateNav();
    try {
      if (type === '3d' || type === 'zoom') await pageAnim(type, swap); else await overlay(type, swap);
    } finally { busy = false; }
    armReveals($('#' + current));
    const h = location.hash.slice(1);
    if (ORDER.includes(h) && h !== current) go(h, false);
  }

  document.addEventListener('click', e => {
    const t = e.target.closest('[data-go]'); if (!t || !ready) return;
    e.preventDefault(); go(t.dataset.go);
  });
  addEventListener('popstate', () => { const h = location.hash.slice(1); go(ORDER.includes(h) ? h : 'home', false); });

  /* ---------- الصوت: واجهة التحكم + المؤثرات ---------- */
  const sndBox = $('#snd'), sndBtn = $('#snd-toggle'), vol = $('#snd-vol');
  vol.value = Math.round(Sound.vol * 100);
  function syncSnd() { sndBox.classList.toggle('off', !Sound.on); sndBtn.setAttribute('aria-pressed', String(Sound.on)); }
  Sound.onchange = syncSnd; syncSnd();
  sndBtn.addEventListener('click', () => { Sound.toggle(); if (Sound.on) Sound.play('click'); });
  vol.addEventListener('input', () => { const v = vol.value / 100; if (!Sound.on && v > 0) Sound.enable(); Sound.setVolume(v); });
  vol.addEventListener('change', () => Sound.play('click'));

  document.addEventListener('pointerdown', e => {
    const t = e.target.closest('a,button,[role="button"],.tile'); if (!t || t.closest('[data-nosound]') || t.hasAttribute('data-nosound') || t.matches('.like,.opt')) return;
    Sound.play('click');
  });
  let lastHover = 0;
  document.addEventListener('pointerover', e => {
    if (e.pointerType !== 'mouse') return;
    const t = e.target.closest('.btn,.nav-links a,.work,.tile,.soc-card,.chap'); if (!t || t.contains(e.relatedTarget)) return;
    const n = performance.now(); if (n - lastHover < 90) return; lastHover = n; Sound.play('hover');
  });

  /* ---------- تأثير الإمالة ثلاثي الأبعاد ---------- */
  if (canHover) {
    document.addEventListener('pointermove', e => {
      const c = e.target.closest('.work,.soc-card,.chap,.card'); if (!c || reduced()) return;
      const r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
      c.style.setProperty('--rx', (-y * 6).toFixed(2) + 'deg'); c.style.setProperty('--ry', (x * 8).toFixed(2) + 'deg');
      c.style.setProperty('--mx', (x + .5) * 100 + '%'); c.style.setProperty('--my', (y + .5) * 100 + '%');
    }, { passive: true });
    document.addEventListener('pointerout', e => { const c = e.target.closest('.work,.soc-card,.chap,.card'); if (c && !c.contains(e.relatedTarget)) { c.style.setProperty('--rx', '0deg'); c.style.setProperty('--ry', '0deg'); } });
  }

  /* ---------- باراليكس + وهج المؤشر ---------- */
  const layers = $$('#home .layer'), glow = $('#cursor-glow');
  let mx = 0, my = 0, tx = 0, ty = 0, gx = innerWidth / 2, gy = innerHeight / 2, gtx = gx, gty = gy, lastSY = -1, running = false;
  addEventListener('pointermove', e => { if (e.pointerType !== 'mouse') return; mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; gtx = e.clientX; gty = e.clientY; }, { passive: true });
  function loop() {
    if (document.hidden) { requestAnimationFrame(loop); return; }
    const sy = scrollY;
    if (!reduced()) {
      tx += (mx - tx) * .07; ty += (my - ty) * .07;
      if (current === 'home' && (Math.abs(mx - tx) > .0005 || Math.abs(my - ty) > .0005 || sy !== lastSY)) {
        layers.forEach(l => {
          const d = parseFloat(l.dataset.depth) || 0.03;
          l.style.transform = `translate3d(${(-tx * d * 900).toFixed(1)}px,${(-ty * d * 600 - sy * d * 5).toFixed(1)}px,0)`;
        });
      }
      if (canHover && glow) {
        gx += (gtx - gx) * .12; gy += (gty - gy) * .12;
        glow.style.transform = `translate3d(${gx - 250}px,${gy - 250}px,0)`;
      }
    }
    lastSY = sy; requestAnimationFrame(loop);
  }

  /* ---------- شاشة التحميل ---------- */
  function boot() {
    splitHeadings(); renderWorks(); renderGallery(); renderSocials(); renderCommunity(); charFallbacks();
    $$('.page').forEach(p => p.classList.toggle('active', p.id === current));
    document.title = '4_AD10 — ' + $('#' + current).dataset.title;
    updateNav();

    const tasks = [];
    tasks.push(Promise.race([document.fonts ? document.fonts.ready : Promise.resolve(), wait(4500)]));
    tasks.push(new Promise(r => { const i = new Image(); i.onload = i.onerror = r; i.src = 'assets/character.png'; setTimeout(r, 5000); }));
    let done = 0; tasks.forEach(t => t.then(() => done++));
    const t0 = performance.now(), MIN = reduced() ? 600 : 2300;
    const fill = $('#ld-fill'), num = $('#ld-num'); let p = 0, finished = false;
    (function tick() {
      const timeP = Math.min(1, (performance.now() - t0) / MIN), taskP = done / tasks.length;
      const target = Math.min(timeP, 0.2 + 0.8 * taskP);
      p += (target - p) * .12; if (target >= 1 && p > .995) p = 1;
      fill.style.transform = `scaleX(${p})`; num.textContent = Math.round(p * 100);
      if (p >= 1 && !finished) { finished = true; $('#ld-gate').hidden = false; $('.ld-center').classList.add('gate'); $('#enter-sound').focus({ preventScroll: true }); return; }
      requestAnimationFrame(tick);
    })();
    setTimeout(() => { if (!finished) { finished = true; fill.style.transform = 'scaleX(1)'; num.textContent = 100; $('#ld-gate').hidden = false; $('.ld-center').classList.add('gate'); } }, 9000);

    const enter = withSound => {
      if (ready) return;
      if (withSound) { Sound.enable(); Sound.play('boom'); }
      ready = true;
      const L = $('#loader'); L.classList.add('done');
      document.body.classList.remove('is-loading'); document.body.classList.add('is-ready');
      setTimeout(() => L.remove(), 1500);
      armReveals($('#' + current));
      history.replaceState({ id: current }, '', '#' + current);
    };
    $('#enter-sound').addEventListener('click', () => enter(true));
    $('#enter-silent').addEventListener('click', () => enter(false));
    requestAnimationFrame(loop);
  }

  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', boot) : boot();
})();
